package interfaceManipulacao;

public interface Manipulacao {
	
	boolean cadastro();
	String consulta();

}
