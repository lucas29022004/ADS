import java.util.Scanner;

import javax.swing.JOptionPane;

public class TestaPessoa {

    public static void main(String[] args) {
      
        Scanner read = new Scanner(System.in);
        while (true) {
            int op = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "Digite uma opção:" + "\n1- Aluno" + "\n2- Professor" + "\n3- Funcionario" + "\n4- Sair"));

            switch (op) {
                case 1:
                    Aluno a = new Aluno();
                    System.out.println("Digite o seu nome: ");
                    a.setNome(read.nextLine());
                    System.out.println("Digite RGM: ");
                    a.setRgm(read.nextLine());
                    a.mostraClasse();
                    System.out.println("__________________________________________________________");
                    break;
                case 2: 
                    Professor p = new Professor();
                    System.out.println("Digite o seu nome: ");
                    p.setNome(read.next());
                    System.out.println("Digite sua matrícula: ");
                    p.setMatricula(read.nextInt());
                    System.out.println("Digite o seu campus: ");
                    p.setCampus(read.next());
                    p.mostraClasse();
                    System.out.println("__________________________________________________________");
                    break;
                case 3:
                Funcionario f = new Funcionario();
                System.out.println("Digite o seu nome: ");
                f.setNome(read.nextLine());
                System.out.println("Digite sua matrícula: ");
                f.setMatricula(read.nextInt());
                System.out.println("Digite o seu setor: ");
                f.setSetor(read.next());
                f.mostraClasse();
                System.out.println("__________________________________________________________");
                break;
                case 4:
                System.out.println("Obrigado por utilizar nossos serviços!");
                System.exit(0);
                break;
                default:{
                    System.out.println("Opção inválida!");
                    System.exit(0);
                }
                    break;
            }

        }
    }
}
