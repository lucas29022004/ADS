public class Funcionario extends Pessoa {

    private int matricula;
    private String setor;

    Funcionario() {

    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    @Override
    public String getNome() {
        // TODO Auto-generated method stub
        return super.getNome();
    }

    @Override
    public void setNome(String nome) {
        // TODO Auto-generated method stub
        super.setNome(nome);
    }

    @Override
    public String mostraClasse() {
        System.out.println("__________________________________________________________");
        System.out.println("Nome: "+getNome());        
        System.out.println("Matrícula: "+getMatricula());        
        System.out.println("Setor: "+getSetor());  
        return null;
    }

}
