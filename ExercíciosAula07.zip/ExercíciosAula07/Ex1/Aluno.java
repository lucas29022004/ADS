public class Aluno extends Pessoa {
    private String rgm;

    Aluno() {

    }

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    @Override
    public String getNome() {
        // TODO Auto-generated method stub
        return super.getNome();
    }

    @Override
    public void setNome(String nome) {
        // TODO Auto-generated method stub
        super.setNome(nome);
    }

    @Override
    public String mostraClasse() {
        System.out.println("__________________________________________________________");
        System.out.println("Nome: "+getNome());
        System.out.println("RGM"+getRgm());
        return null;
    }

}
